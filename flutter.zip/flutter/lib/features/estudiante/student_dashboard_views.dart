import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import 'package:searchteach_mobile/features/tutorias/livekit_room_page.dart';
import 'package:searchteach_mobile/features/tutorias/tutoria_historial_page.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/api_client.dart';
import '../../core/widgets/role_toast.dart';
import '../tutorias/proyecto_aula_chat_page.dart';
import '../tutorias/tutoria_chat_page.dart';
import 'student_dashboard_models.dart';

part 'student_dashboard_home.dart';
part 'student_dashboard_home_widgets.dart';
part 'student_dashboard_tutoring.dart';
part 'student_dashboard_tutoring_widgets.dart';

const _blue = Color(0xFF1769AA);
const _navy = Color(0xFF17324F);
const _muted = Color(0xFF64748B);
const _line = Color(0xFFE4EAF1);
