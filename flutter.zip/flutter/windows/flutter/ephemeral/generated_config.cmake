# Generated code do not commit.
file(TO_CMAKE_PATH "Z:\\" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=Z:\\"
  "PROJECT_DIR=C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter"
  "FLUTTER_ROOT=Z:\\"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter"
  "FLUTTER_TARGET=C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter\\lib\\main.dart"
  "DART_DEFINES=QVBJX0JBU0VfVVJMPWh0dHA6Ly9sb2NhbGhvc3Q6ODA4MQ==,RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuMg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZDNiMTRjODc2OQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YTgwNGIyNjE2NA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\camil\\OneDrive\\Documents\\semestre 6°\\Proyecto de aula\\searchteach\\flutter\\.dart_tool\\package_config.json"
)
