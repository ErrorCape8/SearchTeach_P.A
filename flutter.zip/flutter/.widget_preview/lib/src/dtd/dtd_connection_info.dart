// ignore_for_file: implementation_imports

const String kWidgetPreviewDtdUri = 'ws://127.0.0.1:53872/44RD02AuS3k=';
const String kWidgetPreviewService =
    'widget-preview-6d876ed7-078c-48e7-8240-907146860db9';
const String kWidgetPreviewScaffoldStream =
    'WidgetPreviewScaffold-6d876ed7-078c-48e7-8240-907146860db9';
const String kProjectRootPath =
    r'C:\Users\camil\OneDrive\Documents\semestre 6°\Proyecto de aula\searchteach\flutter';
