package com.pa.searchteach.common.exception;

import com.pa.searchteach.auth.exception.AuthException;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(AuthException.class)
	ResponseEntity<ApiError> handleAuthException(AuthException exception) {
		ApiError body = new ApiError(exception.getMessage(), exception.isRetryable(),
				exception.getRetryAfterSeconds());
		HttpHeaders headers = new HttpHeaders();
		if (exception.getRetryAfterSeconds() > 0) {
			headers.set(HttpHeaders.RETRY_AFTER,
					Long.toString(exception.getRetryAfterSeconds()));
		}
		return new ResponseEntity<>(body, headers, exception.getStatus());
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	ResponseEntity<ApiError> handleValidationException(MethodArgumentNotValidException exception) {
		String field = exception.getBindingResult().getFieldErrors().stream()
				.map(error -> error.getField())
				.findFirst()
				.orElse("");
		String message = switch (field) {
			case "identifier" -> "La identificación debe tener entre 6 y 10 dígitos numéricos.";
			case "password" -> "La contraseña debe tener entre 8 y 72 caracteres.";
			case "email" -> "Escribe un correo electrónico válido.";
			case "code" -> "El código debe tener seis dígitos.";
			case "nuevaContrasena" -> "La nueva contraseña debe tener entre 8 y 72 caracteres.";
			case "confirmarContrasena" -> "Confirma la nueva contraseña.";
			case "telefono" -> "Escribe un teléfono válido: de 7 a 30 caracteres entre dígitos, +, espacios, guiones o paréntesis.";
			default -> "La solicitud contiene un campo obligatorio inválido.";
		};
		return ResponseEntity.badRequest().body(new ApiError(message, true, 0));
	}

	@ExceptionHandler(IllegalArgumentException.class)
	ResponseEntity<ApiError> handleInvalidInput(IllegalArgumentException exception) {
		return ResponseEntity.badRequest().body(new ApiError(exception.getMessage(), false, 0));
	}

	@ExceptionHandler(NotFoundException.class)
	ResponseEntity<ApiError> handleNotFound(NotFoundException exception) {
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(new ApiError(exception.getMessage(), false, 0));
	}

	@ExceptionHandler(ResponseStatusException.class)
	ResponseEntity<ApiError> handleResponseStatus(ResponseStatusException exception) {
		String message = exception.getReason() == null || exception.getReason().isBlank()
				? exception.getStatusCode().toString()
				: exception.getReason();
		return ResponseEntity.status(exception.getStatusCode())
				.body(new ApiError(message, false, 0));
	}

	@ExceptionHandler(ForbiddenException.class)
	ResponseEntity<ApiError> handleForbidden(ForbiddenException exception) {
		return ResponseEntity.status(HttpStatus.FORBIDDEN)
				.body(new ApiError(exception.getMessage(), false, 0));
	}

	public record ApiError(String message, boolean retryable, long retryAfterSeconds) {
	}
}
