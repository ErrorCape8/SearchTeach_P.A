package com.pa.searchteach.tutorias.service.colectivas;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

/**
 * Mueve a {@code grupos_proyectos_aula_invalidos} los documentos de {@code grupos_proyectos_aula}
 * que no cumplen los campos obligatorios de TutoriaColectiva. Un solo documento inválido hace
 * fallar findAll() y con él la pantalla "Proyectos de aula" (HTTP 400) y el scheduler de avisos.
 * No se borra nada: los documentos quedan en la colección de cuarentena.
 */
@Component
@Order(Integer.MAX_VALUE)
public class SaneadorGruposProyectosAula implements ApplicationRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(SaneadorGruposProyectosAula.class);
	private static final String COLECCION = "grupos_proyectos_aula";
	private static final String CUARENTENA = "grupos_proyectos_aula_invalidos";

	private final MongoTemplate mongoTemplate;

	public SaneadorGruposProyectosAula(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	@Override
	public void run(ApplicationArguments args) {
		try {
			MongoCollection<Document> origen = mongoTemplate.getCollection(COLECCION);
			MongoCollection<Document> destino = mongoTemplate.getCollection(CUARENTENA);
			List<Object> movidos = new ArrayList<>();
			for (Document documento : origen.find()) {
				if (!esValido(documento)) {
					Object id = documento.get("_id");
					destino.replaceOne(new Document("_id", id), documento,
							new com.mongodb.client.model.ReplaceOptions().upsert(true));
					movidos.add(id);
				}
			}
			if (!movidos.isEmpty()) {
				origen.deleteMany(new Document("_id", new Document("$in", movidos)));
				LOGGER.warn("Se movieron {} documentos inválidos de {} a {}: {}",
						movidos.size(), COLECCION, CUARENTENA, movidos);
			}
		} catch (Exception exception) {
			LOGGER.error("No se pudo sanear la colección {}.", COLECCION, exception);
		}
	}

	private static boolean esValido(Document d) {
		if (vacio(d.get("coordinadoraId")) || vacio(d.get("docenteLiderId")) || d.get("creadaEn") == null) {
			return false;
		}
		if (!(d.get("docentesApoyoIds") instanceof List<?> apoyo) || apoyo.size() != 5) {
			return false;
		}
		if (!(d.get("proyectos") instanceof List<?>)) {
			return false;
		}
		Object estado = d.get("estado");
		return estado == null || "ACTIVA".equals(estado) || "DISUELTA".equals(estado);
	}

	private static boolean vacio(Object valor) {
		return valor == null || valor.toString().isBlank();
	}
}
